require.config({
    baseUrl: 'scripts',
    paths: {
		'angular': 'js/angular',
		'angular-route': 'js/angular-route',
		'bootstrap': '../lib/bootstrap/js/bootstrap.min',
		'jquery': 'js/jquery'
    },
	shim: {
		'app': {
			deps: ['angular', 'angular-route', 'bootstrap']
		},
		'angular-route': {
			deps: ['angular']
		},
		'bootstrap': {
			deps: ['jquery']
		}
	}
});

require
(
    [
        'app'
    ],
    function(app)
    {
        angular.bootstrap(document, ['app']);
    }
);