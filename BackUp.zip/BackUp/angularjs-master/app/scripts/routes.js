define([], function()
{
    return {
        defaultRoutePath: '/3',
        routes: {
            '/1': {
                templateUrl: 'views/home.html',
                dependencies: [
                    'controllers/HomeViewController'
                ]
            },
            '/2': {
                templateUrl: 'views/about.html',
                dependencies: [
                    'controllers/AboutViewController',
                    'directives/app-color'
                ]
            },
            '/3': {
                templateUrl: 'views/contact.html',
                dependencies: [
                    'controllers/ContactViewController'
                ]
            }
        }
    };
});