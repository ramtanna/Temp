package com.training.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class LoginController {

	@RequestMapping("/")
	public String showLogin(){
		
//		if(true){
//		throw new RuntimeException();
//		}
		return "login";
	}
	
	
	@RequestMapping("/signin")
	public String handleSignInRequest(HttpServletRequest request,Model model){
		
		String uid = request.getParameter("id");
		String pwd = request.getParameter("pass");
		
		// here you will instantiate some java class which will have business logic
		if(uid.equals(pwd)){
			model.addAttribute("username", uid);
			return "welcome";
		}
		else{
			return "login";
		}
		
	}
	
	
}
