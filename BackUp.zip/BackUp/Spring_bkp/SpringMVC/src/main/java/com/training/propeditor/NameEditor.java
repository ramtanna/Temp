package com.training.propeditor;

import java.beans.PropertyEditorSupport;

public class NameEditor extends PropertyEditorSupport{

	@Override
	public void setAsText(String name) throws IllegalArgumentException {
		
		if(name.startsWith("Mr") || name.startsWith("Mrs")){
		setValue(name);
		}
		else{
			name = "Mr."+name;
			setValue(name);
		}
	}
	
	
}
