package com.training.validator;

import org.springframework.stereotype.Service;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.training.dto.Student;

@Service
public class StudentValidator implements Validator{

	@Override
	public boolean supports(Class<?> arg0) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void validate(Object arg0, Errors arg1) {
		Student student = (Student) arg0;
		if(student.getHobby().length()<2 || student.getHobby().length()>8){
			arg1.rejectValue("hobby", "hobby.length", "Hobby should have characters between 2 and 8");
		}
	}

	
}
