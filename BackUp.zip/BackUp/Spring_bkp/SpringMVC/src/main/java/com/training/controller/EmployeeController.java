package com.training.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.training.dto.Employee;

@RestController
@RequestMapping("employees")
public class EmployeeController {

	Employee employee = new Employee();
	
	@RequestMapping(value="/{name}.xml",method=RequestMethod.GET,produces="application/xml")
	public Employee getEmployeeInXml(@PathVariable String name){
		employee.setName(name);
		employee.setEmail("ram_tanna@xyz.com");
		return employee;
	}
	
}
