package com.training.controller;

import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.sun.xml.internal.org.jvnet.staxex.NamespaceContextEx.Binding;
import com.training.dao.StudentDao;
import com.training.dto.Student;
import com.training.propeditor.NameEditor;
import com.training.validator.StudentValidator;

@Controller
public class AdminssionController {

	@Autowired
	StudentValidator studentValidator;
	
	@Autowired
	StudentDao studentDao;
	
	public void inittializeEditor(WebDataBinder bind){
		bind.registerCustomEditor(String.class, "name",new NameEditor());
	}
	
	
	@RequestMapping("/admission")
	public String showAdmission(Map map){
		Student student= new Student();
		map.put("student", student);
		return "admission";
	}
	
	@RequestMapping("/processform")
	public String handleEnrollMe(@Valid @ModelAttribute("student") Student student,
			BindingResult result,Model model){
//		String name = student.getName();
		
		//used for default type of validator
//		studentValidator.validate(student, result);
		if(result.hasErrors()){
			return "admission";
		}
		else{
		studentDao.addStudent(student);
		model.addAttribute("student", student);
		return "angulartut1";
		}
		
	}
	
//	@RequestMapping("processform")
//	public String handleEnrollMe(@RequestParam("name") String name,
//			@RequestParam("mobile") String mobile,
//			@RequestParam("hobby") String hobby,Model model){
//		
//		model.addAttribute("stdname", name);
//		
//		return "enrolled";
//	}
	
	
//	@RequestMapping("processform")
//	public String handleEnrollMe(@RequestParam Map<String, String> mp,Model model){
//		String name = mp.get("name");
//		model.addAttribute("stdname", name);
//		return "enrolled";
//	}
	
}
