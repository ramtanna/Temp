package com.training.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.training.dto.Student;

@Repository
public class StudentDao {

	
	@Autowired
	SessionFactory sessionFactory;
	
	
	
	public void addStudent(Student student) {
		Session session = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		session.save(student);
		transaction.commit();
		session.close();
		System.out.println("1 record inserted successfully");
	}
	
	
}
