package com.demo.clone;

import java.util.Set;
import java.util.TreeSet;

public class Test {

	public static void main(String[] args) {
		
User user1 = new User();
User user2 = new User();
	
User user3 = null;
	try {
		user3 = (User) user2.clone();
	} catch (CloneNotSupportedException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	
	System.out.println(user1.hashCode());
	System.out.println(user2.hashCode());
	System.out.println(user3.hashCode());
	
	System.out.println(user1.toString());
	System.out.println(user2.toString());
	System.out.println(user3.toString());
	
	
	user2.setName("rakesh");
	System.out.println(user1.toString());
	System.out.println(user2.toString());
	System.out.println(user3.toString());
	}
	
}
