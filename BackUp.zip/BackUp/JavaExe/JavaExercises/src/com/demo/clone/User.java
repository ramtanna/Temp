package com.demo.clone;

public class User implements Cloneable{

	protected Object clone() throws CloneNotSupportedException {
		// TODO Auto-generated method stub
		return super.clone();
	}
	
	
	private String name="Ram";
	private String id="Abc";
	
	
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String toString() {
		return "User [name=" + name + ", id=" + id + "]";
	}
	
	
	
	
	
}
