package com.demo.comparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

public class ComparatorDemo {

	
	public static void main(String[] args) {
		
		User user1 = new User("zzz", "1");
		User user2 = new User("aaa", "2");
		User user3 = new User("xxx", "2");
		
		ArrayList<User> arrayList = new ArrayList<User>();
		
		arrayList.add(user1);
		arrayList.add(user2);
		arrayList.add(user3);
		
//		Collections.sort(arrayList);
		
		Comparator<User> userComparator = new Comparator<User>() {
			
			@Override
			public int compare(User o1, User o2) {
				
				return o1.getName().compareTo(o2.getName());
			}
		};
		
		
		Collections.sort(arrayList, userComparator);
		
		
		
		
		
		System.out.println(arrayList.toString());
		
	}
	
	
}
