package com.demo.abstract1;

public class SubClass extends AbstractClass{

	@Override
	public void getName() {
		// TODO Auto-generated method stub
		
	}

}
