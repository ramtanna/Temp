package com.demo.abstract1;



public abstract class AbstractClass {

	public abstract void getName();
	
	public void hello(){
		
	}
	
}
