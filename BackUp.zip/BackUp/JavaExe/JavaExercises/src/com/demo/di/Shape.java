package com.demo.di;

public interface Shape {

	public void draw();
	
}
