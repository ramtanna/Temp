package com.demo.di;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		Factory factory = new Factory();
		
		factory.setShape(new Triangle());
		
		factory.draw();
		
	}

}
