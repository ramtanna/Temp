package com.demo.di;

public class Triangle implements Shape{

	@Override
	public void draw() {
		System.out.println("Inside Triangle");
	}

	
	
}
