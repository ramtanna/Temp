package com.demo.finall;

import java.util.ArrayList;

public final class FinalClass {

	private final String id;
	private final ArrayList<String> arrayList = new ArrayList<String>();
	
	
	public String getId() {
		return id;
	}

	public FinalClass(String id) {
		super();
		this.id = id;
	}

	public ArrayList<String> getArrayList() {
		return arrayList;
	}
	
	
	
}
