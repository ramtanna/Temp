package com.demo.finall;

import java.util.ArrayList;

public class Test {

	public static void main(String[] args) {
		
		
		FinalClass class1= new FinalClass("10");
		
		System.out.println(class1.getId());
		
		class1.getArrayList().add("asdasd");
		
		
//		arrayList.add("Ram");
//		arrayList.add("Ram12");
//		arrayList.add("Ram134");
//		
//		System.out.println(arrayList.toString());
		
	}

	
	
	
	
}
