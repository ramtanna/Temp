package com.demo.twoInterface;

public interface Interface2 {

	public void getName();
	public void getName123();
}
