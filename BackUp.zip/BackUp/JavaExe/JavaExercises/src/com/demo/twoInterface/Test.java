package com.demo.twoInterface;

import java.util.ArrayList;

public class Test {

	public static void main(String[] args) {
		
		
		
		
	}

	
	
	
	
}
