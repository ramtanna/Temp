package com.demo.twoInterface;

public interface Interface1 {

	public void getName();
	
}
