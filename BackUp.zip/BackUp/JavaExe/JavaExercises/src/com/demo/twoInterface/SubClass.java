package com.demo.twoInterface;

public class SubClass implements Interface1,Interface2{

	@Override
	public void getName() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getName123() {
		// TODO Auto-generated method stub
		
	}

}
