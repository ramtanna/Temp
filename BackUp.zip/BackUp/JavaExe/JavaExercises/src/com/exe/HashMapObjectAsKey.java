package com.exe;

import java.util.HashMap;

public class HashMapObjectAsKey {

	
	
	public static void main(String[] args) {
		
		HashMap map = new HashMap();
		User user1= new User();
		User user2= new User();
		map.put(user1, user1);
		map.put(user2, user1);
		
		System.out.println(map.toString());
		
	}
	
	
}
