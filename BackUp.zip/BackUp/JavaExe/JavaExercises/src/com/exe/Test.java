package com.exe;

public class Test {

	
	public static void main(String[] args) {
		
		
		ImmutableClass immutableClass = new ImmutableClass();
		
		
		System.out.println(immutableClass.hashCode());
		
		
		immutableClass.setId(4);
		
		System.out.println(immutableClass.hashCode());
		
		
	}
	
}
