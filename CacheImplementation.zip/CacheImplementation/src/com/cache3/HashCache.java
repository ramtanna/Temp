package com.cache3;



import java.util.HashSet;
import java.util.Iterator;


public class HashCache {

	HashSet<Student> hashSet;
	
			int size;
			int counter=0;

			public HashCache(int size) {
				super();
				this.hashSet = new HashSet<>(size);
				this.size=size;
			}
	
	public void display(){
		System.out.println(hashSet.toString());
	}
	
			public void addElement(String name){
			
			Student student = new Student(name);
	
	
			if(hashSet.contains(student)){
				
				Iterator<Student> iterator =  hashSet.iterator();
			
				while(iterator.hasNext()){
					Student temp = iterator.next();
					if(temp.equals(student)){
						temp.setCounter(temp.getCounter()+1);
					}
				}
				hashSet.add(student);
			}
			else{
				
			
			if(counter == size){
			
				Iterator<Student> iterator =  hashSet.iterator();
			
				Student s= iterator.next();
				while(iterator.hasNext()){
					Student temp = iterator.next();
					if(s.getCounter()>temp.getCounter()){
						s=temp;
					}
				}
				
				hashSet.remove(s);
				hashSet.add(student);
				
			}
			else if(counter<size){
				hashSet.add(student);
				counter++;
			}
			
			
			
			}
			
	
			}
	

	
	
	
	
	
	
}
