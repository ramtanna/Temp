package com.cache3;

import java.util.HashSet;

public class Test {

public static void main(String[] args) {
	

		Student s1 = new Student("Ram");
		Student s2 = new Student("Ram");
		
//		
//		HashSet<Student> hashSet = new HashSet<>();
//		
//		hashSet.add(s1);
//		hashSet.add(s2);
//		s1.setCounter(10);
//		hashSet.add(s1);
//		System.out.println(hashSet.toString());
		
		
		
		HashCache hashCache = new HashCache(3);
		
		hashCache.addElement("A");
		hashCache.addElement("B");
		hashCache.addElement("C");
		hashCache.addElement("D");
		hashCache.addElement("D");
		hashCache.addElement("D");
		hashCache.addElement("A");
		hashCache.addElement("A");
		hashCache.addElement("B");
		hashCache.display();
		
		
}	
	

}
