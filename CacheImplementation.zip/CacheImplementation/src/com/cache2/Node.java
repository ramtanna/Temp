package com.cache2;

public class Node<T> {
     
    private T pageNumber;
    private Node prev;
    private Node next;
     
    public Node(T pageNumber) {
        this.pageNumber = pageNumber;
    }
 
    public T getPageNumber() {
        return pageNumber;
    }
 
    public void setPageNumber(T data) {
        this.pageNumber = data;
    }
     
    public Node getPrev() {
        return prev;
    }
 
    public void setPrev(Node prev) {
        this.prev = prev;
    }
 
    public Node getNext() {
        return next;
    }
 
    public void setNext(Node next) {
        this.next = next;
    }
     
    public String toString() {
        return pageNumber + "  ";
    }
}